﻿var mgr = new Oidc.UserManager();
mgr.signinSilentCallback();
