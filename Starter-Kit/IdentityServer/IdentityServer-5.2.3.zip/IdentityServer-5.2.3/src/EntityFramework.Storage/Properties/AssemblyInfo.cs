﻿// Copyright (c) Duende Software. All rights reserved.
// See LICENSE in the project root for license information.


using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("EntityFramework.Storage.IntegrationTests")]
[assembly: InternalsVisibleTo("EntityFramework.Storage.UnitTests")]
